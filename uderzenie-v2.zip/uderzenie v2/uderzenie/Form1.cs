﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uderzenie
{
    public partial class Form1 : Form
    {
        enum RodzajRury
        {
            Dowolna,
            Stalowa,
            Plastikowa,
            Zelazna
        };

        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs ea)
        {
            double ro, dV, E, k, e, D;
            try
            {
                ro = Convert.ToDouble(textBox1.Text);
                dV = Convert.ToDouble(textBox2.Text);
                E = Convert.ToDouble(textBox3.Text);
                k = Convert.ToDouble(textBox4.Text);
                e = Convert.ToDouble(textBox5.Text);
                D = Convert.ToDouble(textBox6.Text);
            }
            catch(FormatException)
            {
                MessageBox.Show("Wartości muszą być liczbami rzeczywistymi.");
                return;
            }
            catch(OverflowException)
            {
                MessageBox.Show("Jedna z wartości przekracza dopuszczalną wielkość.");
                return;
            }
            Rura rura;
            switch((RodzajRury)comboBox1.SelectedIndex)
            {
                case RodzajRury.Dowolna:
                    rura = new Rura(e, D, ro, dV, E, k);
                    break;
                case RodzajRury.Stalowa:
                    rura = new RuraStalowa(e, D, ro, dV);
                    break;
                // TODO: inne rodzaje rur
                default:
                    MessageBox.Show("Błędny typ rury.");
                    break;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex > 0)
            {
                textBox3.Enabled = false;
                textBox4.Enabled = false;

                switch((RodzajRury)comboBox1.SelectedIndex)
                {
                    case RodzajRury.Stalowa:
                        textBox3.Text = RuraStalowa.E.ToString();
                        textBox4.Text = RuraStalowa.k.ToString();
                        break;
                    // TODO: inne rodzaje rur
                    default:
                        MessageBox.Show("Błędny typ rury.");
                        break;
                }
            }
            else
            {
                textBox3.Enabled = true;
                textBox4.Enabled = true;
                textBox3.Text = "";
                textBox4.Text = "";
            }
        }
    }
}
