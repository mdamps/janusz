﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uderzenie
{
    class Rura : IObliczalna
    {
        private double E;
        private double k;
        public double e { set; protected get; }  // TODO
        public double D { set; protected get; }
        public double ro { set; protected get; }
        public double dV { set; protected get; }

        public Rura(double e, double D, double ro, double dV, double E = 0.0, double k = 0.0)
        {
            this.e = e;
            this.D = D;
            this.ro = ro;
            this.dV = dV;
            this.E = E;
            this.k = k;
            MessageBox.Show("Rura: " + this.e.ToString() + " " + this.D.ToString() + " " + this.ro.ToString() + " " + this.dV.ToString() + " " + this.E.ToString() + " " + this.k.ToString());
        }

        public virtual double obliczPrzyrostCisnienia()
        {
            //tutaj wzor
            return 0;
        }
    }
}
