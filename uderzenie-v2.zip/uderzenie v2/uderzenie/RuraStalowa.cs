﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uderzenie
{
    class RuraStalowa : Rura
    {
        public const double E = 210000.0; // TODO: sprawdzic i jednostki
        public const double k = 0.0125;

        public RuraStalowa(double e, double D, double ro, double dV) : base(e, D, ro, dV)
        {
            MessageBox.Show("Rura stalowa: " + this.e.ToString() + " " + this.D.ToString() + " " + this.ro.ToString() + " " + this.dV.ToString() + " " + RuraStalowa.E.ToString() + " " + RuraStalowa.k.ToString());
        }

        public override double obliczPrzyrostCisnienia()
        {
            //tutaj wzor
            return 0;
        }
    }
}
